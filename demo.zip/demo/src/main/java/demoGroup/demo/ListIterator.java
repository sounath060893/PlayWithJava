
  package demoGroup.demo;
  
  import java.util.Iterator;
  
  
	public class ListIterator<T> implements Iterator<Node> {
		//int size = list.size();
		//int current = 0;
		private Node current;
		public ListIterator(Node first) {
			current=first;
		}
		@Override
		public boolean hasNext() {
			//return current < size;
			return current!=null;
		}

		@Override
		public Node next() {
			/*
			 * T val = (T) list.get(current); current=current+1; return val;
			 */
			Node tempo = current;
	        current = current.getNext();
	        return tempo;
		}
		
		@Override
		public void remove() {
	        if(hasNext()) {
	        	Node prevNode = current.getPrev();
	        	Node nextNode = current.getNext();
	        	current.setPrev(null);
	        	current.setNext(null);
	        	//current.setData(null);
	        	prevNode.setNext(nextNode);
	        }
	    }

	}


 