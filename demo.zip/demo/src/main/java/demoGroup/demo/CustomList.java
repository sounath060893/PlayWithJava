package demoGroup.demo;

import java.util.Iterator;
import java.util.List;

public class CustomList<T> implements Iterable<T> {
	private Node first;
    private Node last;
	private List<T> list;
	public CustomList() {
		first=last=null;
		//this.list = list;
	}
	 public void push(T data) {
	        Node tempo = new Node();
	        tempo.setData(data);
	        tempo.setNext(null);
	        if (first == null) {
	            tempo.setPrev(null);
	            first = last = tempo;
	        } else {
	            tempo.setPrev(last);
	            last.setNext(tempo);
	            last = tempo;
	        }
	    }
	@Override
	public Iterator iterator() {
		return new ListIterator(first);
	}
}
